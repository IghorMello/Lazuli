var marker_div = document.createElement('div');
marker_div.setAttribute('id', 'lazuli_already_installed_marker');

window.onload = function () {
  document.body.appendChild(marker_div);
}
