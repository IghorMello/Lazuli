(function(){
  module.exports = {
    'duolingo/complete_lesson_each_day': require('goals/duolingo/complete_lesson_each_day/measurement')
  };
}).call(this);
